'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, ShoppingCart, Users, Package, TrendingUp, Clock } from 'lucide-react';
import { format } from 'date-fns';

interface Stats {
  todaySales: number;
  todayInvoices: number;
  totalWorkers: number;
  lowStockProducts: number;
  weeklySales: number;
  monthlySales: number;
}

interface RecentInvoice {
  id: string;
  invoice_number: string;
  total: number;
  created_at: string;
  worker_name: string;
}

export default function DashboardPage() {
  const { profile, isOwner } = useAuth();
  const [stats, setStats] = useState<Stats>({
    todaySales: 0,
    todayInvoices: 0,
    totalWorkers: 0,
    lowStockProducts: 0,
    weeklySales: 0,
    monthlySales: 0,
  });
  const [recentInvoices, setRecentInvoices] = useState<RecentInvoice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

      // Today's sales
      const { data: todayData } = await supabase
        .from('invoices')
        .select('total')
        .gte('created_at', today);

      // Today's invoices count
      const { data: todayInvoicesData } = await supabase
        .from('invoices')
        .select('id')
        .gte('created_at', today);

      // Workers count
      const { data: workersData } = await supabase
        .from('profiles')
        .select('id')
        .eq('role', 'worker');

      // Low stock products
      const { data: lowStockData } = await supabase
        .from('products')
        .select('id')
        .lte('stock_quantity', supabase.rpc('min_stock'));

      // Weekly sales
      const { data: weeklyData } = await supabase
        .from('invoices')
        .select('total')
        .gte('created_at', weekAgo);

      // Monthly sales
      const { data: monthlyData } = await supabase
        .from('invoices')
        .select('total')
        .gte('created_at', monthAgo);

      // Recent invoices with worker names
      const { data: invoicesData } = await supabase
        .from('invoices')
        .select(`
          id,
          invoice_number,
          total,
          created_at,
          worker_id
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      let workerNames: { [key: string]: string } = {};
      if (invoicesData) {
        const workerIds = [...new Set(invoicesData.map(i => i.worker_id))];
        for (const workerId of workerIds) {
          const { data: workerData } = await supabase
            .from('profiles')
            .select('full_name')
            .eq('id', workerId)
            .maybeSingle();
          if (workerData) {
            workerNames[workerId] = workerData.full_name;
          }
        }
      }

      setStats({
        todaySales: todayData?.reduce((sum, i) => sum + Number(i.total), 0) || 0,
        todayInvoices: todayInvoicesData?.length || 0,
        totalWorkers: workersData?.length || 0,
        lowStockProducts: lowStockData?.length || 0,
        weeklySales: weeklyData?.reduce((sum, i) => sum + Number(i.total), 0) || 0,
        monthlySales: monthlyData?.reduce((sum, i) => sum + Number(i.total), 0) || 0,
      });

      setRecentInvoices(
        (invoicesData || []).map(i => ({
          ...i,
          worker_name: workerNames[i.worker_id] || 'غير معروف'
        }))
      );
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-800">
          مرحباً، {profile?.full_name || 'مستخدم'}
        </h1>
        <p className="text-gray-500">
          {isOwner ? 'لوحة تحكم صاحب المحل' : 'لوحة تحكم العامل'}
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium opacity-90">مبيعات اليوم</CardTitle>
            <DollarSign className="w-5 h-5 opacity-80" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.todaySales.toFixed(2)}</div>
            <p className="text-xs opacity-80">{stats.todayInvoices} فاتورة</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium opacity-90">مبيعات الأسبوع</CardTitle>
            <TrendingUp className="w-5 h-5 opacity-80" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.weeklySales.toFixed(2)}</div>
            <p className="text-xs opacity-80">آخر 7 أيام</p>
          </CardContent>
        </Card>

        {isOwner && (
          <>
            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium opacity-90">عدد العمال</CardTitle>
                <Users className="w-5 h-5 opacity-80" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalWorkers}</div>
                <p className="text-xs opacity-80">عامل نشط</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium opacity-90">مخزون منخفض</CardTitle>
                <Package className="w-5 h-5 opacity-80" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.lowStockProducts}</div>
                <p className="text-xs opacity-80">منتج يحتاج تعبئة</p>
              </CardContent>
            </Card>
          </>
        )}

        <Card className="bg-gradient-to-br from-teal-500 to-teal-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium opacity-90">مبيعات الشهر</CardTitle>
            <Clock className="w-5 h-5 opacity-80" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.monthlySales.toFixed(2)}</div>
            <p className="text-xs opacity-80">آخر 30 يوم</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Invoices */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            آخر الفواتير
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentInvoices.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              لا توجد فواتير حتى الآن
            </div>
          ) : (
            <div className="space-y-4">
              {recentInvoices.map((invoice) => (
                <div key={invoice.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">{invoice.invoice_number}</p>
                    <p className="text-sm text-gray-500">{invoice.worker_name}</p>
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-green-600">{invoice.total.toFixed(2)}</p>
                    <p className="text-xs text-gray-500">
                      {format(new Date(invoice.created_at), 'HH:mm')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
