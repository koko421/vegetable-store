'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, ShoppingCart, Trash2, Search, Receipt } from 'lucide-react';
import { format } from 'date-fns';

interface Product {
  id: string;
  name: string;
  name_ar: string;
  unit: string;
  price_retail: number;
  price_wholesale: number;
  stock_quantity: number;
}

interface InvoiceItem {
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

interface Invoice {
  id: string;
  invoice_number: string;
  worker_id: string;
  worker_name?: string;
  customer_name?: string;
  customer_phone?: string;
  invoice_type: 'retail' | 'wholesale';
  subtotal: number;
  discount: number;
  total: number;
  created_at: string;
}

export default function InvoicesPage() {
  const { user, profile, isOwner } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [invoiceType, setInvoiceType] = useState<'retail' | 'wholesale'>('retail');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [discount, setDiscount] = useState(0);
  const [cart, setCart] = useState<InvoiceItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    fetchProducts();
    fetchInvoices();
  }, []);

  const fetchProducts = async () => {
    try {
      const { data } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .order('name');
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const fetchInvoices = async () => {
    try {
      let query = supabase
        .from('invoices')
        .select('*')
        .order('created_at', { ascending: false });

      if (!isOwner) {
        query = query.eq('worker_id', user?.id);
      }

      const { data } = await query.limit(50);
      setInvoices(data || []);
    } catch (error) {
      console.error('Error fetching invoices:', error);
    } finally {
      setLoading(false);
    }
  };

  const addToCart = () => {
    if (!selectedProduct || quantity <= 0) return;

    const product = products.find(p => p.id === selectedProduct);
    if (!product) return;

    const existingItem = cart.find(item => item.product_id === selectedProduct);
    if (existingItem) {
      setCart(cart.map(item =>
        item.product_id === selectedProduct
          ? {
              ...item,
              quantity: item.quantity + quantity,
              total_price: (item.quantity + quantity) * item.unit_price,
            }
          : item
      ));
    } else {
      const price = invoiceType === 'wholesale' ? product.price_wholesale : product.price_retail;
      setCart([
        ...cart,
        {
          product_id: product.id,
          product_name: product.name_ar || product.name,
          quantity,
          unit_price: price,
          total_price: price * quantity,
        },
      ]);
    }

    setSelectedProduct('');
    setQuantity(1);
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.product_id !== productId));
  };

  const subtotal = cart.reduce((sum, item) => sum + item.total_price, 0);
  const total = subtotal - discount;

  const generateInvoiceNumber = () => {
    const date = new Date();
    const dateStr = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`;
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `INV-${dateStr}-${random}`;
  };

  const createInvoice = async () => {
    if (cart.length === 0) return;

    try {
      const invoiceNumber = generateInvoiceNumber();

      const { data: invoice, error: invoiceError } = await supabase
        .from('invoices')
        .insert({
          invoice_number: invoiceNumber,
          worker_id: user?.id,
          customer_name: customerName || null,
          customer_phone: customerPhone || null,
          invoice_type: invoiceType,
          subtotal,
          discount,
          total,
          notes: notes || null,
        })
        .select()
        .maybeSingle();

      if (invoiceError) throw invoiceError;

      const invoiceItems = cart.map(item => ({
        invoice_id: invoice.id,
        product_id: item.product_id,
        product_name: item.product_name,
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_price: item.total_price,
      }));

      const { error: itemsError } = await supabase.from('invoice_items').insert(invoiceItems);
      if (itemsError) throw itemsError;

      // Update stock
      for (const item of cart) {
        const product = products.find(p => p.id === item.product_id);
        if (product) {
          await supabase
            .from('products')
            .update({ stock_quantity: product.stock_quantity - item.quantity })
            .eq('id', item.product_id);
        }
      }

      // Reset form
      setCart([]);
      setCustomerName('');
      setCustomerPhone('');
      setNotes('');
      setDiscount(0);
      setDialogOpen(false);

      // Refresh data
      fetchProducts();
      fetchInvoices();
    } catch (error) {
      console.error('Error creating invoice:', error);
    }
  };

  const filteredInvoices = invoices.filter(inv =>
    inv.invoice_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (inv.customer_name && inv.customer_name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">الفواتير</h1>
          <p className="text-gray-500">إنشاء وإدارة الفواتير</p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" />
              فاتورة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Receipt className="w-5 h-5" />
                إنشاء فاتورة جديدة
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* Invoice Type & Customer */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>نوع الفاتورة</Label>
                  <Select value={invoiceType} onValueChange={(v) => setInvoiceType(v as any)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="retail">تجزئة</SelectItem>
                      <SelectItem value="wholesale">جملة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>اسم العميل (اختياري)</Label>
                  <Input
                    placeholder="اسم العميل"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>رقم هاتف العميل (اختياري)</Label>
                  <Input
                    placeholder="رقم الهاتف"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>الخصم</Label>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    value={discount}
                    onChange={(e) => setDiscount(Number(e.target.value))}
                  />
                </div>
              </div>

              {/* Product Selection */}
              <div className="space-y-4">
                <h3 className="font-medium">إضافة منتج</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2 col-span-2">
                    <Label>المنتج</Label>
                    <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر المنتج" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map((product) => (
                          <SelectItem key={product.id} value={product.id}>
                            {product.name_ar || product.name} - {invoiceType === 'wholesale' ? product.price_wholesale : product.price_retail}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>الكمية</Label>
                    <Input
                      type="number"
                      min="1"
                      value={quantity}
                      onChange={(e) => setQuantity(Number(e.target.value))}
                    />
                  </div>
                </div>
                <Button variant="outline" onClick={addToCart}>
                  <Plus className="w-4 h-4 mr-2" />
                  إضافة للسلة
                </Button>
              </div>

              {/* Cart */}
              {cart.length > 0 && (
                <div className="space-y-4">
                  <h3 className="font-medium">سلة المشتريات</h3>
                  <div className="border rounded-lg divide-y">
                    {cart.map((item) => (
                      <div key={item.product_id} className="flex items-center justify-between p-3">
                        <div>
                          <p className="font-medium">{item.product_name}</p>
                          <p className="text-sm text-gray-500">
                            {item.quantity} × {item.unit_price.toFixed(2)}
                          </p>
                        </div>
                        <div className="flex items-center gap-4">
                          <p className="font-bold">{item.total_price.toFixed(2)}</p>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeFromCart(item.product_id)}
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex justify-between text-lg font-bold">
                    <span>المجموع</span>
                    <span className="text-green-600">{total.toFixed(2)}</span>
                  </div>
                </div>
              )}

              {/* Notes */}
              <div className="space-y-2">
                <Label>ملاحظات</Label>
                <Textarea
                  placeholder="ملاحظات إضافية..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>

              <Button
                className="w-full bg-green-600 hover:bg-green-700"
                onClick={createInvoice}
                disabled={cart.length === 0}
              >
                <Receipt className="w-4 h-4 mr-2" />
                حفظ الفاتورة
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <Input
          className="pr-10"
          placeholder="البحث في الفواتير..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Invoices List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          </div>
        ) : filteredInvoices.length === 0 ? (
          <div className="col-span-full text-center py-12 text-gray-500">
            لا توجد فواتير
          </div>
        ) : (
          filteredInvoices.map((invoice) => (
            <Card key={invoice.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center justify-between">
                  <span className="text-lg">{invoice.invoice_number}</span>
                  <span className={`px-2 py-1 rounded text-xs ${
                    invoice.invoice_type === 'wholesale'
                      ? 'bg-purple-100 text-purple-700'
                      : 'bg-blue-100 text-blue-700'
                  }`}>
                    {invoice.invoice_type === 'wholesale' ? 'جملة' : 'تجزئة'}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  {invoice.customer_name && (
                    <p className="text-gray-600">
                      <span className="font-medium">العميل:</span> {invoice.customer_name}
                    </p>
                  )}
                  <p className="text-gray-600">
                    <span className="font-medium">التاريخ:</span>{' '}
                    {format(new Date(invoice.created_at), 'yyyy/MM/dd HH:mm')}
                  </p>
                  <p className="text-gray-600">
                    <span className="font-medium">الخصم:</span> {invoice.discount.toFixed(2)}
                  </p>
                  <p className="text-xl font-bold text-green-600 pt-2">
                    {invoice.total.toFixed(2)}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
