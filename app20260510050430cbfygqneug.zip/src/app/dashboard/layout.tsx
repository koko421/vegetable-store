'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Leaf, LayoutDashboard, ShoppingCart, Package, Users, BarChart3, LogOut, Menu } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { user, profile, loading, signOut, isOwner } = useAuth();

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const handleSignOut = async () => {
    await signOut();
    router.push('/login');
  };

  const navItems = [
    { href: '/dashboard', label: 'الرئيسية', icon: LayoutDashboard },
    { href: '/dashboard/invoices', label: 'الفواتير', icon: ShoppingCart },
    { href: '/dashboard/workers', label: 'العمال', icon: Users, ownerOnly: true },
    { href: '/dashboard/products', label: 'المنتجات', icon: Package },
    { href: '/dashboard/reports', label: 'التقارير', icon: BarChart3 },
  ];

  const filteredNav = navItems.filter(item => !item.ownerOnly || isOwner);

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r shadow-sm">
        <div className="p-6 border-b">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-600 rounded-lg">
              <Leaf className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-green-800">محل الخضار</h1>
              <p className="text-xs text-gray-500">
                {isOwner ? 'صاحب المحل' : 'عامل'}
              </p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {filteredNav.map((item) => (
            <Link key={item.href} href={item.href}>
              <Button variant="ghost" className="w-full justify-start gap-3">
                <item.icon className="w-5 h-5" />
                {item.label}
              </Button>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t">
          <div className="mb-4 px-3">
            <p className="font-medium text-sm">{profile?.full_name || 'مستخدم'}</p>
            <p className="text-xs text-gray-500">{profile?.email}</p>
          </div>
          <Button variant="outline" className="w-full justify-start gap-3 text-red-600" onClick={handleSignOut}>
            <LogOut className="w-5 h-5" />
            تسجيل الخروج
          </Button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white border-b z-50 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-600 rounded-lg">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-green-800">محل الخضار</span>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <div className="p-6 border-b">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-600 rounded-lg">
                    <Leaf className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h1 className="font-bold text-green-800">محل الخضار</h1>
                    <p className="text-xs text-gray-500">
                      {isOwner ? 'صاحب المحل' : 'عامل'}
                    </p>
                  </div>
                </div>
              </div>
              <nav className="p-4 space-y-2">
                {filteredNav.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <Button variant="ghost" className="w-full justify-start gap-3">
                      <item.icon className="w-5 h-5" />
                      {item.label}
                    </Button>
                  </Link>
                ))}
              </nav>
              <div className="p-4 border-t">
                <div className="mb-4 px-3">
                  <p className="font-medium text-sm">{profile?.full_name || 'مستخدم'}</p>
                  <p className="text-xs text-gray-500">{profile?.email}</p>
                </div>
                <Button variant="outline" className="w-full justify-start gap-3 text-red-600" onClick={handleSignOut}>
                  <LogOut className="w-5 h-5" />
                  تسجيل الخروج
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-8 pt-20 md:pt-8 overflow-auto">
        {children}
      </main>
    </div>
  );
}
