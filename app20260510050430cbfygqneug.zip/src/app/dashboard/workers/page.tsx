'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Users, Mail, Phone, Edit, Trash2, UserCheck } from 'lucide-react';
import { toast } from 'sonner';

interface Worker {
  id: string;
  email: string | null;
  full_name: string;
  phone: string | null;
  role: string;
  is_active: boolean;
  created_at: string;
  today_sales?: number;
  today_invoices?: number;
}

export default function WorkersPage() {
  const { isOwner, profile } = useAuth();
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editWorker, setEditWorker] = useState<Worker | null>(null);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    full_name: '',
    phone: '',
  });

  useEffect(() => {
    if (isOwner) {
      fetchWorkers();
    }
  }, [isOwner]);

  const fetchWorkers = async () => {
    try {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'worker')
        .order('created_at', { ascending: false });

      const today = new Date().toISOString().split('T')[0];

      const workersWithStats = await Promise.all(
        (data || []).map(async (worker) => {
          const { data: salesData } = await supabase
            .from('invoices')
            .select('total')
            .eq('worker_id', worker.id)
            .gte('created_at', today);

          const { data: invoicesData } = await supabase
            .from('invoices')
            .select('id')
            .eq('worker_id', worker.id)
            .gte('created_at', today);

          return {
            ...worker,
            today_sales: salesData?.reduce((sum, inv) => sum + Number(inv.total), 0) || 0,
            today_invoices: invoicesData?.length || 0,
          };
        })
      );

      setWorkers(workersWithStats);
    } catch (error) {
      console.error('Error fetching workers:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editWorker) {
        // Update existing worker
        const { error } = await supabase
          .from('profiles')
          .update({
            full_name: formData.full_name,
            phone: formData.phone || null,
          })
          .eq('id', editWorker.id);

        if (error) throw error;
        toast.success('تم تحديث بيانات العامل بنجاح');
      } else {
        // Create new worker
        const { data, error } = await supabase.auth.admin.createUser({
          email: formData.email,
          password: formData.password,
          email_confirm: true,
          user_metadata: {
            full_name: formData.full_name,
            role: 'worker',
          },
        });

        if (error) throw error;

        if (data.user) {
          await supabase.from('profiles').insert({
            id: data.user.id,
            email: formData.email,
            full_name: formData.full_name,
            phone: formData.phone || null,
            role: 'worker',
            is_active: true,
          });

          await supabase.from('user_roles').insert({
            user_id: data.user.id,
            role: 'worker',
            is_active: true,
          });
        }

        toast.success('تم إضافة العامل بنجاح');
      }

      setDialogOpen(false);
      resetForm();
      fetchWorkers();
    } catch (error: any) {
      toast.error(error.message || 'حدث خطأ');
    }
  };

  const handleEdit = (worker: Worker) => {
    setEditWorker(worker);
    setFormData({
      email: worker.email || '',
      password: '',
      full_name: worker.full_name,
      phone: worker.phone || '',
    });
    setDialogOpen(true);
  };

  const handleToggleActive = async (worker: Worker) => {
    try {
      await supabase
        .from('profiles')
        .update({ is_active: !worker.is_active })
        .eq('id', worker.id);

      await supabase
        .from('user_roles')
        .update({ is_active: !worker.is_active })
        .eq('user_id', worker.id);

      toast.success(`تم ${worker.is_active ? 'تعطيل' : 'تفعيل'} العامل`);
      fetchWorkers();
    } catch (error) {
      toast.error('حدث خطأ');
    }
  };

  const resetForm = () => {
    setEditWorker(null);
    setFormData({ email: '', password: '', full_name: '', phone: '' });
  };

  if (!isOwner) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-gray-500">ليس لديك صلاحية الوصول لهذه الصفحة</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">العمال</h1>
          <p className="text-gray-500">إدارة فريق العمل</p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" />
              إضافة عامل
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editWorker ? 'تعديل بيانات العامل' : 'إضافة عامل جديد'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              {!editWorker && (
                <>
                  <div className="space-y-2">
                    <Label>البريد الإلكتروني</Label>
                    <Input
                      type="email"
                      placeholder="email@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>كلمة المرور</Label>
                    <Input
                      type="password"
                      placeholder="********"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      required={!editWorker}
                      minLength={6}
                    />
                  </div>
                </>
              )}
              <div className="space-y-2">
                <Label>الاسم الكامل</Label>
                <Input
                  type="text"
                  placeholder="اسم العامل"
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>رقم الهاتف</Label>
                <Input
                  type="tel"
                  placeholder="05xxxxxxxx"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>
              <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                {editWorker ? 'حفظ التغييرات' : 'إضافة'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
        </div>
      ) : workers.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="w-12 h-12 text-gray-400 mb-4" />
            <p className="text-gray-500">لا يوجد عمال مسجلين</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {workers.map((worker) => (
            <Card key={worker.id} className={!worker.is_active ? 'opacity-60' : ''}>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-green-100 rounded-full">
                      <Users className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-bold">{worker.full_name}</p>
                      <p className={`text-xs font-normal ${worker.is_active ? 'text-green-600' : 'text-red-500'}`}>
                        {worker.is_active ? 'نشط' : 'غير نشط'}
                      </p>
                    </div>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Mail className="w-4 h-4" />
                  {worker.email || 'غير محدد'}
                </div>
                {worker.phone && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="w-4 h-4" />
                    {worker.phone}
                  </div>
                )}
                <div className="pt-3 border-t space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">مبيعات اليوم</span>
                    <span className="font-bold text-green-600">
                      {worker.today_sales?.toFixed(2) || '0.00'}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">فواتير اليوم</span>
                    <span className="font-bold">{worker.today_invoices || 0}</span>
                  </div>
                </div>
                <div className="flex gap-2 pt-3">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => handleEdit(worker)}
                  >
                    <Edit className="w-4 h-4 mr-1" />
                    تعديل
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleToggleActive(worker)}
                  >
                    <UserCheck className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
