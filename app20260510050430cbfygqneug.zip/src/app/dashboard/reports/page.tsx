'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, TrendingUp, Users, ShoppingCart, Calendar, DollarSign } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Legend } from 'recharts';
import { format, startOfDay, endOfDay, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from 'date-fns';

interface DailySales {
  date: string;
  sales: number;
  invoices: number;
}

interface WorkerSales {
  name: string;
  sales: number;
  invoices: number;
}

interface CategorySales {
  name: string;
  value: number;
}

interface TopProduct {
  name: string;
  quantity: number;
  revenue: number;
}

const COLORS = ['#22c55e', '#3b82f6', '#a855f7', '#f59e0b', '#ef4444', '#06b6d4', '#ec4899'];

export default function ReportsPage() {
  const { isOwner } = useAuth();
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('week');
  const [dailySales, setDailySales] = useState<DailySales[]>([]);
  const [workerSales, setWorkerSales] = useState<WorkerSales[]>([]);
  const [categorySales, setCategorySales] = useState<CategorySales[]>([]);
  const [topProducts, setTopProducts] = useState<TopProduct[]>([]);
  const [summary, setSummary] = useState({
    totalSales: 0,
    totalInvoices: 0,
    avgInvoice: 0,
    topWorker: '',
  });

  useEffect(() => {
    fetchReportData();
  }, [period]);

  const getDateRange = () => {
    const now = new Date();
    let start: Date;
    let end = now;

    switch (period) {
      case 'today':
        start = startOfDay(now);
        end = endOfDay(now);
        break;
      case 'week':
        start = startOfWeek(now);
        end = endOfWeek(now);
        break;
      case 'month':
        start = startOfMonth(now);
        end = endOfMonth(now);
        break;
      case '3months':
        start = subDays(now, 90);
        end = now;
        break;
      default:
        start = startOfWeek(now);
        end = endOfWeek(now);
    }

    return { start: start.toISOString(), end: end.toISOString() };
  };

  const fetchReportData = async () => {
    setLoading(true);
    try {
      const { start, end } = getDateRange();

      // Fetch all invoices in period
      const { data: invoices } = await supabase
        .from('invoices')
        .select(`
          id,
          total,
          created_at,
          worker_id,
          invoice_items (
            product_id,
            quantity,
            total_price,
            product:products(category_id, category:categories(name_ar))
          )
        `)
        .gte('created_at', start)
        .lte('created_at', end);

      // Calculate daily sales
      const dailyMap: { [key: string]: { sales: number; invoices: number } } = {};
      const workerMap: { [key: string]: { sales: number; invoices: number; name: string } } = {};
      const categoryMap: { [key: string]: number } = {};
      let totalSales = 0;
      let totalInvoices = 0;

      // Fetch worker names
      const { data: profiles } = await supabase.from('profiles').select('id, full_name');
      const profileMap: { [key: string]: string } = {};
      (profiles || []).forEach(p => {
        profileMap[p.id] = p.full_name;
      });

      for (const invoice of invoices || []) {
        const date = format(new Date(invoice.created_at), 'yyyy-MM-dd');
        const workerName = profileMap[invoice.worker_id] || 'غير معروف';

        // Daily
        if (!dailyMap[date]) {
          dailyMap[date] = { sales: 0, invoices: 0 };
        }
        dailyMap[date].sales += Number(invoice.total);
        dailyMap[date].invoices += 1;

        // Worker
        if (!workerMap[invoice.worker_id]) {
          workerMap[invoice.worker_id] = { sales: 0, invoices: 0, name: workerName };
        }
        workerMap[invoice.worker_id].sales += Number(invoice.total);
        workerMap[invoice.worker_id].invoices += 1;

        // Category
        for (const item of invoice.invoice_items || []) {
          const categoryName = (item as any).category?.name_ar || (item as any).category?.name || 'أخرى';
          categoryMap[categoryName] = (categoryMap[categoryName] || 0) + Number(item.total_price);
        }

        totalSales += Number(invoice.total);
        totalInvoices += 1;
      }

      // Format daily sales
      const sortedDates = Object.keys(dailyMap).sort();
      setDailySales(sortedDates.map(date => ({
        date: format(new Date(date), 'MM/dd'),
        sales: dailyMap[date].sales,
        invoices: dailyMap[date].invoices,
      })));

      // Format worker sales
      const sortedWorkers = Object.entries(workerMap)
        .sort((a, b) => b[1].sales - a[1].sales);
      setWorkerSales(sortedWorkers.map(([_, data]) => ({
        name: data.name,
        sales: data.sales,
        invoices: data.invoices,
      })));

      // Top worker
      const topWorker = sortedWorkers.length > 0 ? sortedWorkers[0][1].name : '-';

      // Category sales
      setCategorySales(
        Object.entries(categoryMap)
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value)
      );

      setSummary({
        totalSales,
        totalInvoices,
        avgInvoice: totalInvoices > 0 ? totalSales / totalInvoices : 0,
        topWorker,
      });

      // Top products
      const productMap: { [key: string]: { name: string; quantity: number; revenue: number } } = {};
      for (const invoice of invoices || []) {
        for (const item of invoice.invoice_items || []) {
          if (!productMap[item.product_id]) {
            productMap[item.product_id] = { name: (item as any).product_name || 'منتج', quantity: 0, revenue: 0 };
          }
          productMap[item.product_id].quantity += Number(item.quantity);
          productMap[item.product_id].revenue += Number(item.total_price);
        }
      }
      setTopProducts(
        Object.entries(productMap)
          .map(([_, data]) => data)
          .sort((a, b) => b.revenue - a.revenue)
          .slice(0, 5)
      );

    } catch (error) {
      console.error('Error fetching reports:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">التقارير</h1>
          <p className="text-gray-500">إحصائيات وتحليلات المبيعات</p>
        </div>

        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">اليوم</SelectItem>
            <SelectItem value="week">هذا الأسبوع</SelectItem>
            <SelectItem value="month">هذا الشهر</SelectItem>
            <SelectItem value="3months">آخر 3 أشهر</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium opacity-90">إجمالي المبيعات</CardTitle>
            <DollarSign className="w-5 h-5 opacity-80" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary.totalSales.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium opacity-90">عدد الفواتير</CardTitle>
            <ShoppingCart className="w-5 h-5 opacity-80" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary.totalInvoices}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium opacity-90">متوسط الفاتورة</CardTitle>
            <BarChart3 className="w-5 h-5 opacity-80" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary.avgInvoice.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium opacity-90">أفضل بائع</CardTitle>
            <TrendingUp className="w-5 h-5 opacity-80" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold truncate">{summary.topWorker}</div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <Tabs defaultValue="daily" className="space-y-4">
        <TabsList>
          <TabsTrigger value="daily">المبيعات اليومية</TabsTrigger>
          <TabsTrigger value="workers">المبيعات حسب العامل</TabsTrigger>
          <TabsTrigger value="categories">المبيعات حسب الفئة</TabsTrigger>
          <TabsTrigger value="products">أفضل المنتجات</TabsTrigger>
        </TabsList>

        <TabsContent value="daily">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                المبيعات اليومية
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-64 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                </div>
              ) : dailySales.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-gray-500">
                  لا توجد بيانات
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={dailySales}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip formatter={(value) => `${Number(value).toFixed(2)}`} />
                    <Bar dataKey="sales" fill="#22c55e" name="المبيعات" />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="workers">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                مبيعات العمال
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-64 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                </div>
              ) : workerSales.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-gray-500">
                  لا توجد بيانات
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={workerSales} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip formatter={(value) => `${Number(value).toFixed(2)}`} />
                    <Bar dataKey="sales" fill="#3b82f6" name="المبيعات" />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                المبيعات حسب الفئة
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-64 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                </div>
              ) : categorySales.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-gray-500">
                  لا توجد بيانات
                </div>
              ) : (
                <div className="flex items-center justify-center">
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={categorySales}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {categorySales.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${Number(value).toFixed(2)}`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                أفضل المنتجات مبيعاً
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-64 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                </div>
              ) : topProducts.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-gray-500">
                  لا توجد بيانات
                </div>
              ) : (
                <div className="space-y-4">
                  {topProducts.map((product, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                          index === 0 ? 'bg-yellow-500 text-white' :
                          index === 1 ? 'bg-gray-400 text-white' :
                          index === 2 ? 'bg-orange-500 text-white' :
                          'bg-gray-200 text-gray-600'
                        }`}>
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-gray-500">{product.quantity} وحدة</p>
                        </div>
                      </div>
                      <div className="text-left">
                        <p className="font-bold text-green-600">{product.revenue.toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
