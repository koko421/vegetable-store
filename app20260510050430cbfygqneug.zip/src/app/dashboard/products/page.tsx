'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Package, Plus, Edit, Trash2, Search, AlertTriangle, Leaf } from 'lucide-react';
import { toast } from 'sonner';

interface Category {
  id: string;
  name: string;
  name_ar: string;
}

interface Product {
  id: string;
  category_id: string;
  category_name?: string;
  name: string;
  name_ar: string;
  unit: string;
  price_retail: number;
  price_wholesale: number;
  stock_quantity: number;
  min_stock: number;
  is_active: boolean;
}

export default function ProductsPage() {
  const { isOwner } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStock, setFilterStock] = useState<string>('all');
  const [formData, setFormData] = useState({
    name: '',
    name_ar: '',
    category_id: '',
    unit: 'kg',
    price_retail: 0,
    price_wholesale: 0,
    stock_quantity: 0,
    min_stock: 10,
  });

  useEffect(() => {
    fetchCategories();
    fetchProducts();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data } = await supabase
        .from('categories')
        .select('*')
        .order('name');
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchProducts = async () => {
    try {
      const { data } = await supabase
        .from('products')
        .select('*, category:categories(name, name_ar)')
        .order('name');

      const productsWithCategory = (data || []).map((p: any) => ({
        ...p,
        category_name: p.category?.name_ar || p.category?.name,
      }));

      setProducts(productsWithCategory);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editProduct) {
        const { error } = await supabase
          .from('products')
          .update({
            name: formData.name,
            name_ar: formData.name_ar,
            category_id: formData.category_id || null,
            unit: formData.unit,
            price_retail: formData.price_retail,
            price_wholesale: formData.price_wholesale,
            stock_quantity: formData.stock_quantity,
            min_stock: formData.min_stock,
          })
          .eq('id', editProduct.id);

        if (error) throw error;
        toast.success('تم تحديث المنتج بنجاح');
      } else {
        const { error } = await supabase.from('products').insert({
          name: formData.name,
          name_ar: formData.name_ar,
          category_id: formData.category_id || null,
          unit: formData.unit,
          price_retail: formData.price_retail,
          price_wholesale: formData.price_wholesale,
          stock_quantity: formData.stock_quantity,
          min_stock: formData.min_stock,
          is_active: true,
        });

        if (error) throw error;
        toast.success('تم إضافة المنتج بنجاح');
      }

      setDialogOpen(false);
      resetForm();
      fetchProducts();
    } catch (error: any) {
      toast.error(error.message || 'حدث خطأ');
    }
  };

  const handleEdit = (product: Product) => {
    setEditProduct(product);
    setFormData({
      name: product.name,
      name_ar: product.name_ar,
      category_id: product.category_id || '',
      unit: product.unit,
      price_retail: product.price_retail,
      price_wholesale: product.price_wholesale,
      stock_quantity: product.stock_quantity,
      min_stock: product.min_stock,
    });
    setDialogOpen(true);
  };

  const handleToggleActive = async (product: Product) => {
    try {
      await supabase
        .from('products')
        .update({ is_active: !product.is_active })
        .eq('id', product.id);

      toast.success(`تم ${product.is_active ? 'إخفاء' : 'إظهار'} المنتج`);
      fetchProducts();
    } catch (error) {
      toast.error('حدث خطأ');
    }
  };

  const resetForm = () => {
    setEditProduct(null);
    setFormData({
      name: '',
      name_ar: '',
      category_id: '',
      unit: 'kg',
      price_retail: 0,
      price_wholesale: 0,
      stock_quantity: 0,
      min_stock: 10,
    });
  };

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (product.name_ar && product.name_ar.includes(searchQuery));

    const matchesCategory =
      filterCategory === 'all' || product.category_id === filterCategory;

    const matchesStock =
      filterStock === 'all' ||
      (filterStock === 'low' && product.stock_quantity <= product.min_stock) ||
      (filterStock === 'out' && product.stock_quantity === 0) ||
      (filterStock === 'available' && product.stock_quantity > product.min_stock);

    return matchesSearch && matchesCategory && matchesStock;
  });

  const lowStockCount = products.filter(p => p.stock_quantity <= p.min_stock).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">المنتجات</h1>
          <p className="text-gray-500">
            إدارة المنتجات والمخزون
            {lowStockCount > 0 && (
              <span className="text-orange-600 font-medium mr-2">
                ({lowStockCount} منتج منخفض المخزون)
              </span>
            )}
          </p>
        </div>

        {isOwner && (
          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                إضافة منتج
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>
                  {editProduct ? 'تعديل المنتج' : 'إضافة منتج جديد'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>الاسم (English)</Label>
                    <Input
                      placeholder="Tomatoes"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>الاسم (العربية)</Label>
                    <Input
                      placeholder="طماطم"
                      value={formData.name_ar}
                      onChange={(e) => setFormData({ ...formData, name_ar: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>الفئة</Label>
                  <Select
                    value={formData.category_id}
                    onValueChange={(v) => setFormData({ ...formData, category_id: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر الفئة" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.id}>
                          {cat.name_ar || cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>الوحدة</Label>
                  <Select
                    value={formData.unit}
                    onValueChange={(v) => setFormData({ ...formData, unit: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg">كيلوغرام (kg)</SelectItem>
                      <SelectItem value="bundle">حزمة</SelectItem>
                      <SelectItem value="piece">قطعة</SelectItem>
                      <SelectItem value="box">صندوق</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>سعر التجزئة</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.price_retail}
                      onChange={(e) => setFormData({ ...formData, price_retail: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>سعر الجملة</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.price_wholesale}
                      onChange={(e) => setFormData({ ...formData, price_wholesale: Number(e.target.value) })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>المخزون</Label>
                    <Input
                      type="number"
                      min="0"
                      value={formData.stock_quantity}
                      onChange={(e) => setFormData({ ...formData, stock_quantity: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>حد التنبيه</Label>
                    <Input
                      type="number"
                      min="0"
                      value={formData.min_stock}
                      onChange={(e) => setFormData({ ...formData, min_stock: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>الوحدة</Label>
                    <Input value={formData.unit} disabled />
                  </div>
                </div>

                <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                  {editProduct ? 'حفظ التغييرات' : 'إضافة المنتج'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            className="pr-10"
            placeholder="البحث في المنتجات..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger>
            <SelectValue placeholder="الفئة" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الفئات</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat.id} value={cat.id}>
                {cat.name_ar || cat.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterStock} onValueChange={setFilterStock}>
          <SelectTrigger>
            <SelectValue placeholder="حالة المخزون" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع المنتجات</SelectItem>
            <SelectItem value="low">منخفض المخزون</SelectItem>
            <SelectItem value="out">نفذ المخزون</SelectItem>
            <SelectItem value="available">متوفر</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Products Grid */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
        </div>
      ) : filteredProducts.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Package className="w-12 h-12 text-gray-400 mb-4" />
            <p className="text-gray-500">لا توجد منتجات</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredProducts.map((product) => {
            const isLowStock = product.stock_quantity <= product.min_stock;
            const isOutOfStock = product.stock_quantity === 0;

            return (
              <Card
                key={product.id}
                className={`${!product.is_active ? 'opacity-50' : ''} ${
                  isLowStock ? 'border-orange-300' : ''
                } ${isOutOfStock ? 'border-red-300' : ''}`}
              >
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-full ${
                        isOutOfStock ? 'bg-red-100' : isLowStock ? 'bg-orange-100' : 'bg-green-100'
                      }`}>
                        <Leaf className={`w-4 h-4 ${
                          isOutOfStock ? 'text-red-600' : isLowStock ? 'text-orange-600' : 'text-green-600'
                        }`} />
                      </div>
                      <span className="text-lg">{product.name_ar || product.name}</span>
                    </div>
                    {isLowStock && (
                      <AlertTriangle className={`w-5 h-5 ${
                        isOutOfStock ? 'text-red-500' : 'text-orange-500'
                      }`} />
                    )}
                  </CardTitle>
                  {product.category_name && (
                    <p className="text-sm text-gray-500">{product.category_name}</p>
                  )}
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-gray-50 rounded">
                      <p className="text-gray-500">تجزئة</p>
                      <p className="font-bold">{product.price_retail.toFixed(2)}</p>
                    </div>
                    <div className="p-2 bg-purple-50 rounded">
                      <p className="text-gray-500">جملة</p>
                      <p className="font-bold">{product.price_wholesale.toFixed(2)}</p>
                    </div>
                  </div>

                  <div className={`p-3 rounded-lg ${
                    isOutOfStock ? 'bg-red-50' : isLowStock ? 'bg-orange-50' : 'bg-green-50'
                  }`}>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">المخزون</span>
                      <span className={`font-bold ${
                        isOutOfStock ? 'text-red-600' : isLowStock ? 'text-orange-600' : 'text-green-600'
                      }`}>
                        {product.stock_quantity} {product.unit}
                      </span>
                    </div>
                    <div className="mt-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          isOutOfStock ? 'bg-red-500' : isLowStock ? 'bg-orange-500' : 'bg-green-500'
                        }`}
                        style={{
                          width: `${Math.min(100, (product.stock_quantity / (product.min_stock * 2)) * 100)}%`
                        }}
                      />
                    </div>
                  </div>

                  {isOwner && (
                    <div className="flex gap-2 pt-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleEdit(product)}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        تعديل
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleToggleActive(product)}
                      >
                        {product.is_active ? 'إخفاء' : 'إظهار'}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
