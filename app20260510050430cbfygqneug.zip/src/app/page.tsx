'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Leaf, ShoppingCart, Users, BarChart3, ArrowLeft } from 'lucide-react';

export default function HomePage() {
  const router = useRouter();
  const { user, loading } = useAuth();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (mounted && !loading && user) {
      router.push('/dashboard');
    }
  }, [user, loading, mounted, router]);

  if (!mounted || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-emerald-100">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  if (user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <header className="p-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-600 rounded-xl shadow-lg">
              <Leaf className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-green-800">محل الخضار</h1>
              <p className="text-sm text-green-600">نظام إدارة المبيعات</p>
            </div>
          </div>
          <Link href="/login">
            <Button className="bg-green-600 hover:bg-green-700">
              تسجيل الدخول
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <main className="max-w-6xl mx-auto px-6 py-12">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            نظام متكامل لإدارة
            <span className="text-green-600"> محلات الخضار</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            ربط صاحب المحل مع عماله في شبكة مغلقة لمتابعة المبيعات والفواتير بسهولة
          </p>
          <Link href="/login">
            <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-6">
              ابدأ الآن
              <ArrowLeft className="w-5 h-5 mr-2" />
            </Button>
          </Link>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="border-2 border-green-100 hover:border-green-300 transition-colors">
            <CardHeader>
              <div className="p-3 bg-green-100 rounded-lg w-fit mb-4">
                <ShoppingCart className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>إدارة الفواتير</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-600">
              إنشاء وتتبع الفواتير بسهولة مع إمكانية البيع بالتجزئة والجملة
            </CardContent>
          </Card>

          <Card className="border-2 border-green-100 hover:border-green-300 transition-colors">
            <CardHeader>
              <div className="p-3 bg-blue-100 rounded-lg w-fit mb-4">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>شبكة العمال</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-600">
              ربط جميع العمال بصاحب المحل لمتابعة أداء كل عامل
            </CardContent>
          </Card>

          <Card className="border-2 border-green-100 hover:border-green-300 transition-colors">
            <CardHeader>
              <div className="p-3 bg-purple-100 rounded-lg w-fit mb-4">
                <BarChart3 className="w-6 h-6 text-purple-600" />
              </div>
              <CardTitle>التقارير والإحصائيات</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-600">
              تقارير تفصيلية عن المبيعات والمنتجات والعمال
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <footer className="mt-16 text-center text-gray-500">
          <p>نظام محلات الخضار - جميع الحقوق محفوظة</p>
        </footer>
      </main>
    </div>
  );
}
